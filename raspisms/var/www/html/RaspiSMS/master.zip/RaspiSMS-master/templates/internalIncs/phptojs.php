<script>
	var HTTP_PWD = '<?php echo addslashes(HTTP_PWD); ?>';
</script>
